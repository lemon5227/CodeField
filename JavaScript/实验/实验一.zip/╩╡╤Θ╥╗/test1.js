function a(){
    document.write("这是第一个JavaScript例子!");
}